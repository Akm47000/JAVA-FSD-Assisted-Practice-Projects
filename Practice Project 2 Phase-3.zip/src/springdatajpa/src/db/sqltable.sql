use mydb;
create table product(id bigint(255) auto_increment,
name varchar(255),
description varchar(255),
price decimal,
primary key(id)
); 
select * from product;