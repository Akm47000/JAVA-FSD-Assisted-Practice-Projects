public class car 
{  
    String name; 
    String brand; 
    int model; 
    String color; 
    public car(String name, String brand, int model, String color) 
    { 
        this.name = name; 
        this.brand = brand; 
        this.model = model; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String getBrand() 
    { 
        return brand; 
    } 
    public int getModel() 
    { 
        return model; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ ".\nMy car brand, model and color are " + this.getBrand()+", " + this.getModel()+ ", and" 
    + this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        car akanksh = new car("Akanksh","Maruthi Swift", 2015, "black"); 
        System.out.println(akanksh.toString()); 
    } 
}
