package pack2;
import pack1.*;

public class accessModifiers3 extends proaccessModifiers {
	
	public static void main(String[] args) {
		accessModifiers3 obj = new accessModifiers3 ();   
	       obj.display();  
	}

}
