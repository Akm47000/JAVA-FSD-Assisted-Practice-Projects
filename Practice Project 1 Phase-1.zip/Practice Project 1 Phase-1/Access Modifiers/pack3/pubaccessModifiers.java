package pack3;

public class pubaccessModifiers {
	
	public void display() 
    { 
        System.out.println("This is Public Access Modifiers"); 
    } 
}


