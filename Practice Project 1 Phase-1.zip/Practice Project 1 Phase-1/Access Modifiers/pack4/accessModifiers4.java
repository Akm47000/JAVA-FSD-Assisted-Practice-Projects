package pack4;
import pack3.*;

public class accessModifiers4 {
	
public static void main(String[] args) {
		
		pubaccessModifiers obj = new pubaccessModifiers(); 
        obj.display();  
		
	}


}
