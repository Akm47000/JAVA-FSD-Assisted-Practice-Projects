package springmvcorm.dao;

import springmvcorm.entity.User;

public interface UserDao {

	int create(User user);
	
}