package com.samples.InterfaceInjection.DAO;

public interface OrderDAO {

	void createOrder();
	
}