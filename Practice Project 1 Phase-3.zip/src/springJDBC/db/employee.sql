use mydb;

create table employee1(id int, firstname varchar(20), lastname varchar(20));

select * from employee1;