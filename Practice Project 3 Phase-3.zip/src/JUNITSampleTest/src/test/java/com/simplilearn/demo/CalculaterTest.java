package com.simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculaterTest {
	
		private  Calculator calc;
		
		@BeforeEach 
		public void steup() {
			calc =new Calculator();
			System.out.println("Calculater Intiated");
		}
		@AfterEach
		public void tearDown() {
			calc=null;
			System.out.println("Calculator Closed");
		}
		@Test
		public void addtest() {
			assertEquals(24, calc.add(13, 11));
		}
		@Test
		public void subtest() {
			assertEquals(6, calc.sub(10, 4));
			assertNotEquals(8, calc.sub(11, 4));
		}
		
		@Test
		public void multiplytest() {
			assertEquals(24, calc.multiply(6, 4));
			assertNotEquals(35, calc.multiply(11, 3));
		}
		
		@Test
		public void dividetest() {
			assertEquals(6, calc.divide(36, 6));
			
		}

}
