package com.simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Assertion {

	public boolean checkAge(int age) {
		 
		 return age>=18;
		 
	 }
	 
	 @Test
	 public void testAsserions() {
		 
		 assertEquals(12, 4+8);
		 assertNotEquals(8, 4+2);
		 
		 //assertTrue(checkAge(19));
		 //assertTrue(checkAge(9));
		 int a=56;
		 int b=72;
		// assertTrue(b>a);
		 assertFalse(a>b);
		 String name=null;
		assertNull(name);
		 
		 String name1="Akanksh";
		 assertNotNull(name1);
}
	 
	 @Test
	 @DisplayName("Test Exception using Lambda")
	 public void testThrow() {
		 
		 assertThrows(RuntimeException.class, ()->
		 {throw new RuntimeException("not valid");});
		 
		 assertThrows(ArithmeticException.class, ()->
		 {int x=10/0;System.out.println(x);});
		 
		// assertThrows(NullPointerException.class, ()->
		 //{String x=null;System.out.println(x.toLowerCase());});
	 }
}
