package com.simplilearn.demo;

public class UserAuthentication {
	public String username()
	{
		String email = "akm@gmail.com";
		return email;
	}
	
	public String paswd()
	{
		String password = "07042000";
		return password;
	}
	
	

}
