package pack1;

public class proaccessModifiers {
	protected void display() 
    { 
        System.out.println("This is protected accessmodifier"); 
    } 
}
