function b() { }

function a() {
    b();
}

a();