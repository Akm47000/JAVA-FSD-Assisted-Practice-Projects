var a = 2,
    b = 3,
    c = 4;

a = b = c;

console.log(a);
console.log(b);
console.log(c);